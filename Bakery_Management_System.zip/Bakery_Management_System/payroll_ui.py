from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget, QTableWidgetItem, QHBoxLayout, QLineEdit
from PySide6.QtGui import QFont
import sys

class PayrollUI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Payroll Management")
        self.showMaximized()
        self.main_ui = main_ui
        
        layout = QVBoxLayout()
        
        title = QLabel("Payroll Management")
        title.setFont(QFont("Arial", 16))
        layout.addWidget(title)
        
        # Payroll Table
        self.payroll_table = QTableWidget()
        self.payroll_table.setColumnCount(5)
        self.payroll_table.setHorizontalHeaderLabels(["Employee Name", "Position", "Salary", "Tax Deduction", "Net Salary"])
        layout.addWidget(self.payroll_table)
        
        # Input Fields
        self.entries = {}
        fields = ["Employee Name", "Position", "Salary", "Tax Deduction (%)"]
        for field in fields:
            label = QLabel(field)
            entry = QLineEdit()
            layout.addWidget(label)
            layout.addWidget(entry)
            self.entries[field] = entry
        
        # Action Buttons
        button_layout = QHBoxLayout()
        
        add_button = QPushButton("Add Payroll Record")
        add_button.clicked.connect(self.add_payroll)
        button_layout.addWidget(add_button)
        
        delete_button = QPushButton("Delete Record")
        delete_button.clicked.connect(self.delete_payroll)
        button_layout.addWidget(delete_button)
        
        layout.addLayout(button_layout)
        
        # Home Button
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self.go_home)
        layout.addWidget(home_btn)
        
        self.setLayout(layout)
    
    def add_payroll(self):
        """Adds a new payroll record."""
        employee_name = self.entries["Employee Name"].text()
        position = self.entries["Position"].text()
        salary = self.entries["Salary"].text()
        tax_percentage = self.entries["Tax Deduction (%)"].text()
        
        if not all([employee_name, position, salary, tax_percentage]):
            print("Error: All fields must be filled!")
            return
        
        try:
            salary = float(salary)
            tax_percentage = float(tax_percentage)
            tax_amount = (tax_percentage / 100) * salary
            net_salary = salary - tax_amount
        except ValueError:
            print("Error: Salary and Tax Deduction must be valid numbers!")
            return
        
        row_position = self.payroll_table.rowCount()
        self.payroll_table.insertRow(row_position)
        for col, data in enumerate([employee_name, position, salary, tax_amount, net_salary]):
            self.payroll_table.setItem(row_position, col, QTableWidgetItem(str(data)))
        
        print("Payroll record added successfully!")
    
    def delete_payroll(self):
        """Deletes the selected payroll record."""
        selected_row = self.payroll_table.currentRow()
        if selected_row == -1:
            print("Error: No record selected!")
            return
        
        self.payroll_table.removeRow(selected_row)
        print("Payroll record deleted successfully!")
    
    def go_home(self):
        """Navigate back to the appropriate home screen based on role."""
        self.main_ui.load_home(self.main_ui.current_role)

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PayrollUI(None)  # For testing purposes
    window.show()
    sys.exit(app.exec())
