from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget,
    QTableWidgetItem, QHBoxLayout, QLineEdit, QMessageBox, QFormLayout
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
import sys

class PayrollUI(QWidget):
    def __init__(self, main_ui=None):
        super().__init__()
        self.setWindowTitle("Payroll Management")
        self.resize(1000, 700)
        self.main_ui = main_ui

        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        title = QLabel("Payroll Management")
        title.setFont(QFont("Arial", 20))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        self.payroll_table = QTableWidget()
        self.payroll_table.setColumnCount(5)
        self.payroll_table.setHorizontalHeaderLabels(["Employee Name", "Position", "Salary", "Tax Deduction", "Net Salary"])
        main_layout.addWidget(self.payroll_table)

        form_layout = QFormLayout()
        form_layout.setSpacing(10)

        self.entries = {}
        fields = ["Employee Name", "Position", "Salary", "Tax Deduction (%)"]
        for field in fields:
            entry = QLineEdit()
            entry.setFixedHeight(35)
            entry.setStyleSheet("border-radius: 10px; padding-left: 8px;")
            form_layout.addRow(QLabel(field), entry)
            self.entries[field] = entry

        main_layout.addLayout(form_layout)

        button_layout = QHBoxLayout()

        add_button = QPushButton("Add Payroll Record")
        add_button.setFixedHeight(40)
        add_button.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 20px;")
        add_button.clicked.connect(self.add_payroll)
        button_layout.addWidget(add_button)

        delete_button = QPushButton("Delete Record")
        delete_button.setFixedHeight(40)
        delete_button.setStyleSheet("background-color: #f44336; color: white; border-radius: 20px;")
        delete_button.clicked.connect(self.delete_payroll)
        button_layout.addWidget(delete_button)

        home_btn = QPushButton("Home")
        home_btn.setFixedHeight(40)
        home_btn.setStyleSheet("background-color: #2196F3; color: white; border-radius: 20px;")
        home_btn.clicked.connect(self.go_home)
        button_layout.addWidget(home_btn)

        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

    def add_payroll(self):
        employee_name = self.entries["Employee Name"].text()
        position = self.entries["Position"].text()
        salary = self.entries["Salary"].text()
        tax_percentage = self.entries["Tax Deduction (%)"].text()

        if not all([employee_name, position, salary, tax_percentage]):
            QMessageBox.warning(self, "Error", "All fields must be filled!")
            return

        try:
            salary = float(salary)
            tax_percentage = float(tax_percentage)
            tax_amount = (tax_percentage / 100) * salary
            net_salary = salary - tax_amount
        except ValueError:
            QMessageBox.warning(self, "Error", "Salary and Tax Deduction must be valid numbers!")
            return

        row_position = self.payroll_table.rowCount()
        self.payroll_table.insertRow(row_position)
        data = [employee_name, position, f"${salary:.2f}", f"${tax_amount:.2f}", f"${net_salary:.2f}"]

        for col, item in enumerate(data):
            self.payroll_table.setItem(row_position, col, QTableWidgetItem(item))

        QMessageBox.information(self, "Success", "Payroll record added successfully!")

    def delete_payroll(self):
        selected_row = self.payroll_table.currentRow()
        if selected_row != -1:
            self.payroll_table.removeRow(selected_row)
            QMessageBox.information(self, "Success", "Payroll record deleted successfully!")
        else:
            QMessageBox.warning(self, "Error", "No record selected!")

    def go_home(self):
        self.main_ui.load_home()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PayrollUI()
    window.show()
    sys.exit(app.exec())