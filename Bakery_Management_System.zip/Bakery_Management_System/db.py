import sqlite3
import bcrypt

DB_NAME = "bakery_system.db"

def connect_db():
    """Establish a connection to the SQLite database."""
    return sqlite3.connect(DB_NAME)

def initialize_db():
    """Ensure the database and required tables exist before use."""
    conn = connect_db()
    cursor = conn.cursor()

    # Create users table if it doesn't exist
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    """)

    # Create inventory table if it doesn't exist
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL
        )
    """)

    conn.commit()
    conn.close()

def migrate_passwords():
    """Migrate plaintext passwords to hashed passwords if needed."""
    conn = connect_db()
    cursor = conn.cursor()

    # Fetch all users with plaintext passwords (assuming non-hashed are less than 60 chars)
    cursor.execute("SELECT username, password FROM users WHERE LENGTH(password) < 60")
    users = cursor.fetchall()

    for username, plaintext_password in users:
        hashed_password = bcrypt.hashpw(plaintext_password.encode(), bcrypt.gensalt()).decode()
        cursor.execute("UPDATE users SET password = ? WHERE username = ?", (hashed_password, username))

    conn.commit()
    conn.close()
    print("Password migration complete!")

# Ensure database is initialized before running
initialize_db()
migrate_passwords()
