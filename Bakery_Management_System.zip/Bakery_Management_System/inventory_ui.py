from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget, QTableWidgetItem, QHBoxLayout, QLineEdit
from PySide6.QtGui import QFont
import sqlite3
import sys

DB_NAME = "bakery_system.db"

class InventoryUI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Inventory Management")
        self.showMaximized()
        self.main_ui = main_ui
        
        layout = QVBoxLayout()
        
        title = QLabel("Inventory Management")
        title.setFont(QFont("Arial", 16))
        layout.addWidget(title)
        
        # Inventory Table
        self.inventory_table = QTableWidget()
        self.inventory_table.setColumnCount(5)
        self.inventory_table.setHorizontalHeaderLabels(["Item Name", "Category", "Quantity", "Cost Price", "Selling Price"])
        layout.addWidget(self.inventory_table)
        
        # Load inventory from database
        self.load_inventory()
        
        # Input Fields
        self.entries = {}
        fields = ["Item Name", "Category", "Quantity", "Cost Price", "Selling Price"]
        for field in fields:
            label = QLabel(field)
            entry = QLineEdit()
            layout.addWidget(label)
            layout.addWidget(entry)
            self.entries[field] = entry
        
        # Action Buttons
        button_layout = QHBoxLayout()
        
        add_button = QPushButton("Add Item")
        add_button.clicked.connect(self.add_item_to_inventory)
        button_layout.addWidget(add_button)
        
        delete_button = QPushButton("Delete Item")
        delete_button.clicked.connect(self.delete_item_from_inventory)
        button_layout.addWidget(delete_button)
        
        update_button = QPushButton("Update Item")
        update_button.clicked.connect(self.update_inventory_item)
        button_layout.addWidget(update_button)
        
        layout.addLayout(button_layout)
        
        # Home Button
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self.go_home)
        layout.addWidget(home_btn)
        
        self.setLayout(layout)
    
    def load_inventory(self):
        """Fetch and display inventory items from the database."""
        self.inventory_table.setRowCount(0)  # Clear table before reloading
        
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT item_name, category, quantity, cost_price, selling_price FROM inventory")
        data = cursor.fetchall()
        conn.close()
        
        for row_data in data:
            row_position = self.inventory_table.rowCount()
            self.inventory_table.insertRow(row_position)
            for col, value in enumerate(row_data):
                self.inventory_table.setItem(row_position, col, QTableWidgetItem(str(value)))
    
    def add_item_to_inventory(self):
        """Adds a new inventory item."""
        item_name = self.entries["Item Name"].text()
        category = self.entries["Category"].text()
        quantity = self.entries["Quantity"].text()
        cost_price = self.entries["Cost Price"].text()
        selling_price = self.entries["Selling Price"].text()
        
        if not all([item_name, category, quantity, cost_price, selling_price]):
            print("Error: All fields must be filled!")
            return
        
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO inventory (item_name, category, quantity, cost_price, selling_price) VALUES (?, ?, ?, ?, ?)",
                       (item_name, category, quantity, cost_price, selling_price))
        conn.commit()
        conn.close()
        
        self.load_inventory()
        print("Item added successfully!")
    
    def delete_item_from_inventory(self):
        """Deletes the selected item from the inventory."""
        selected_row = self.inventory_table.currentRow()
        if selected_row == -1:
            print("Error: No item selected!")
            return
        
        item_name = self.inventory_table.item(selected_row, 0).text()
        
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM inventory WHERE item_name = ?", (item_name,))
        conn.commit()
        conn.close()
        
        self.load_inventory()
        print("Item deleted successfully!")
    
    def update_inventory_item(self):
        """Updates the selected inventory item."""
        selected_row = self.inventory_table.currentRow()
        if selected_row == -1:
            print("Error: No item selected!")
            return
        
        item_name = self.entries["Item Name"].text()
        category = self.entries["Category"].text()
        quantity = self.entries["Quantity"].text()
        cost_price = self.entries["Cost Price"].text()
        selling_price = self.entries["Selling Price"].text()
        
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE inventory SET category = ?, quantity = ?, cost_price = ?, selling_price = ? WHERE item_name = ?",
                       (category, quantity, cost_price, selling_price, item_name))
        conn.commit()
        conn.close()
        
        self.load_inventory()
        print("Item updated successfully!")
    
    def go_home(self):
        """Navigate back to the appropriate home screen based on role."""
        self.main_ui.load_home(self.main_ui.current_role)

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryUI(None)  # For testing purposes
    window.show()
    sys.exit(app.exec())