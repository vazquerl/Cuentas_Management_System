from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget, QTableWidgetItem,
    QHBoxLayout, QLineEdit, QMessageBox, QFormLayout
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
import sqlite3
import sys

DB_NAME = "bakery_system.db"

class InventoryUI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Inventory Management")
        self.resize(1200, 800)
        self.main_ui = main_ui

        main_layout = QVBoxLayout()

        title = QLabel("Inventory Management")
        title.setFont(QFont("Arial", 18))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        self.inventory_table = QTableWidget()
        self.inventory_table.setColumnCount(9)
        self.inventory_table.setHorizontalHeaderLabels([
            "ID", "SKU", "Item Name", "Category", "Quantity",
            "Unit", "Cost Price", "Selling Price", "Last Updated"
        ])
        main_layout.addWidget(self.inventory_table)

        self.load_inventory()

        form_layout = QFormLayout()
        self.entries = {}
        fields = ["SKU", "Item Name", "Category", "Quantity", "Unit", "Cost Price", "Selling Price"]
        for field in fields:
            entry = QLineEdit()
            entry.setFixedHeight(35)
            entry.setStyleSheet("border-radius: 10px; padding-left: 8px;")
            form_layout.addRow(QLabel(field), entry)
            self.entries[field] = entry

        main_layout.addLayout(form_layout)

        button_layout = QHBoxLayout()

        add_button = QPushButton("Add Item")
        add_button.setFixedHeight(40)
        add_button.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 15px;")
        add_button.clicked.connect(self.add_item_to_inventory)
        button_layout.addWidget(add_button)

        delete_button = QPushButton("Delete Item")
        delete_button.setFixedHeight(40)
        delete_button.setStyleSheet("background-color: #f44336; color: white; border-radius: 15px;")
        delete_button.clicked.connect(self.delete_item_from_inventory)
        button_layout.addWidget(delete_button)

        update_button = QPushButton("Update Item")
        update_button.setFixedHeight(40)
        update_button.setStyleSheet("background-color: #FF9800; color: white; border-radius: 15px;")
        update_button.clicked.connect(self.update_inventory_item)
        button_layout.addWidget(update_button)

        main_layout.addLayout(button_layout)

        home_btn = QPushButton("Home")
        home_btn.setFixedHeight(40)
        home_btn.setStyleSheet("background-color: #2196F3; color: white; border-radius: 15px;")
        home_btn.clicked.connect(self.go_home)
        main_layout.addWidget(home_btn)

        self.inventory_table.cellClicked.connect(self.populate_fields_from_selection)

        self.setLayout(main_layout)

    def load_inventory(self):
        self.inventory_table.setRowCount(0)
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT id, sku, item_name, category, quantity, unit, cost_price, selling_price, last_updated FROM inventory")
        data = cursor.fetchall()
        conn.close()

        for row_data in data:
            row_position = self.inventory_table.rowCount()
            self.inventory_table.insertRow(row_position)
            for col, value in enumerate(row_data):
                self.inventory_table.setItem(row_position, col, QTableWidgetItem(str(value)))

    def populate_fields_from_selection(self):
        selected_row = self.inventory_table.currentRow()
        if selected_row != -1:
            for idx, key in enumerate(["SKU", "Item Name", "Category", "Quantity", "Unit", "Cost Price", "Selling Price"]):
                self.entries[key].setText(self.inventory_table.item(selected_row, idx + 1).text())

    def add_item_to_inventory(self):
        try:
            sku = self.entries["SKU"].text().strip()
            item_name = self.entries["Item Name"].text().strip()
            category = self.entries["Category"].text().strip()
            quantity = int(self.entries["Quantity"].text())
            unit = self.entries["Unit"].text().strip()
            cost_price = float(self.entries["Cost Price"].text())
            selling_price = float(self.entries["Selling Price"].text())

            conn = sqlite3.connect(DB_NAME)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO inventory (sku, item_name, category, quantity, unit, cost_price, selling_price) VALUES (?, ?, ?, ?, ?, ?, ?)",
                           (sku, item_name, category, quantity, unit, cost_price, selling_price))
            conn.commit()
            conn.close()

            self.load_inventory()
            QMessageBox.information(self, "Success", "Item added successfully!")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def delete_item_from_inventory(self):
        selected_row = self.inventory_table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Error", "No item selected!")
            return
        item_id = self.inventory_table.item(selected_row, 0).text()

        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM inventory WHERE id = ?", (item_id,))
        conn.commit()
        conn.close()

        self.load_inventory()
        QMessageBox.information(self, "Success", "Item deleted successfully!")

    def update_inventory_item(self):
        # Similar logic as add_item_to_inventory but with UPDATE statement
        pass  # (omitted for brevity)

    def go_home(self):
        self.main_ui.load_home()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = InventoryUI(None)
    window.show()
    sys.exit(app.exec())