import bcrypt
from database_utils import connect_db

def login_user(username, password):
    """Validates user login credentials."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT role, password FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    conn.close()

    if user:
        role, stored_password = user
        if bcrypt.checkpw(password.encode(), stored_password.encode()):
            return role  # Return role if authentication is successful
    return None  # Return None if authentication fails