from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, 
    QComboBox, QHBoxLayout, QMessageBox, QFormLayout, QFrame
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
import sys
import bcrypt
import random

class RegistrationUI(QWidget):
    def __init__(self, main_ui=None):
        super().__init__()
        self.setWindowTitle("Employee Registration")
        self.resize(600, 700)
        self.main_ui = main_ui

        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        title = QLabel("Register New Employee")
        title.setFont(QFont("Arial", 20))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        form_layout = QFormLayout()
        form_layout.setSpacing(10)

        self.entries = {}
        labels = [
            "Username", "First Name", "Last Name", "Email", "DOB", 
            "Address", "Phone Number", "City", "State", "Zip Code", "Password"
        ]

        for label in labels:
            entry = QLineEdit()
            entry.setFixedHeight(35)
            entry.setStyleSheet("border-radius: 10px; padding-left: 8px;")
            if label == "Password":
                entry.setEchoMode(QLineEdit.Password)
            form_layout.addRow(QLabel(label), entry)
            self.entries[label] = entry

        self.role_dropdown = QComboBox()
        self.role_dropdown.addItems(["Owner", "Manager", "Cashier", "Baker"])
        self.role_dropdown.setFixedHeight(35)
        self.role_dropdown.setStyleSheet("border-radius: 10px; padding-left: 8px;")
        form_layout.addRow(QLabel("Role"), self.role_dropdown)

        main_layout.addLayout(form_layout)

        button_layout = QHBoxLayout()

        register_btn = QPushButton("Register")
        register_btn.setFixedHeight(40)
        register_btn.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 20px;")
        register_btn.clicked.connect(self.register)
        button_layout.addWidget(register_btn)

        home_btn = QPushButton("Home")
        home_btn.setFixedHeight(40)
        home_btn.setStyleSheet("background-color: #2196F3; color: white; border-radius: 20px;")
        home_btn.clicked.connect(self.go_home)
        button_layout.addWidget(home_btn)

        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

    def register(self):
        if not self.main_ui or not hasattr(self.main_ui, 'current_role'):
            QMessageBox.warning(self, "Error", "Main UI not set! Cannot determine role.")
            return

        current_role = self.main_ui.current_role
        if current_role not in ["Owner", "Manager"]:
            QMessageBox.warning(self, "Permission Denied", "Only Owner or Manager can register new users!")
            return

        data = {key: self.entries[key].text().strip() for key in self.entries}
        role = self.role_dropdown.currentText().strip()

        if not all(data.values()):
            QMessageBox.warning(self, "Missing Fields", "All fields must be filled!")
            return

        hashed_password = bcrypt.hashpw(data["Password"].encode(), bcrypt.gensalt()).decode()
        QMessageBox.information(self, "Success", f"New Employee Registered: {data['Username']}, Role: {role}")

    def go_home(self):
        self.main_ui.load_home()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RegistrationUI()
    window.show()
    sys.exit(app.exec())