from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, QComboBox, QHBoxLayout, QMessageBox
from PySide6.QtGui import QFont
import sys
import bcrypt
import random


class RegistrationUI(QWidget):
    def __init__(self, main_ui=None):
        super().__init__()
        self.setWindowTitle("Employee Registration")
        self.showMaximized()
        self.main_ui = main_ui

        layout = QVBoxLayout()

        # Dynamic Header Controlled by Main_UI
        self.menu_layout = QHBoxLayout()
        layout.addLayout(self.menu_layout)
        self.update_menu()

        title = QLabel("Register New Employee")
        title.setFont(QFont("Arial", 16))
        layout.addWidget(title)

        self.entries = {}
        labels = ["Username", "First Name", "Last Name", "Email", "DOB", "Address", "Phone Number", "City", "State", "Zip Code", "Password"]

        for label in labels:
            lbl = QLabel(f"{label}:")
            entry = QLineEdit()
            if label == "Password":
                entry.setEchoMode(QLineEdit.Password)
            layout.addWidget(lbl)
            layout.addWidget(entry)
            self.entries[label] = entry

        # Role Selection
        role_label = QLabel("Role:")
        self.role_dropdown = QComboBox()
        self.role_dropdown.addItems(["Owner", "Manager", "Cashier", "Baker"])
        layout.addWidget(role_label)
        layout.addWidget(self.role_dropdown)

        # Buttons Layout
        button_layout = QHBoxLayout()

        # Register Button
        register_btn = QPushButton("Register")
        register_btn.clicked.connect(self.register)
        button_layout.addWidget(register_btn)

        # Home Button
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self.go_home)
        button_layout.addWidget(home_btn)

        layout.addLayout(button_layout)

        self.setLayout(layout)

    def register(self):
        """Registers a new employee, verifies role."""
        if not self.main_ui or not hasattr(self.main_ui, 'current_role'):
            self.show_error("Error", "Main UI is not set! Cannot determine role.")
            return

        current_role = self.main_ui.current_role
        if current_role not in ["Owner", "Manager"]:
            self.show_error("Permission Denied", "Only Owner or Manager can register new users!")
            return

        employee_id = "EMP" + str(random.randint(1000, 9999))

        data = {key: self.entries[key].text().strip() for key in self.entries}
        role = self.role_dropdown.currentText().strip()

        if not all(data.values()):
            self.show_error("Missing Fields", "All fields must be filled!")
            return

        hashed_password = bcrypt.hashpw(data["Password"].encode(), bcrypt.gensalt()).decode()

        self.show_message("Success", f"New Employee Registered: {data['Username']}, Role: {role}")

    def go_back(self):
        """Return to the login screen."""
        if self.main_ui and hasattr(self.main_ui, 'login_ui'):
            self.main_ui.login_ui()
        else:
            self.show_error("Error", "Main UI not set!")

    def go_home(self):
        """Navigate back to the appropriate home screen based on role."""
        if self.main_ui and hasattr(self.main_ui, 'load_home'):
            self.main_ui.load_home(self.main_ui.current_role)
        else:
            self.show_error("Error", "Main UI not set!")

    def update_menu(self):
        """Placeholder function for updating the menu."""
        pass  # Prevent crashes due to undefined method

    def show_error(self, title, message):
        """Displays an error message."""
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()

    def show_message(self, title, message):
        """Displays an informational message."""
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec()


# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RegistrationUI()  # Test case with no main UI
    window.show()
    sys.exit(app.exec())
