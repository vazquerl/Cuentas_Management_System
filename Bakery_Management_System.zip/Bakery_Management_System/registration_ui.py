from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, QComboBox, QHBoxLayout
from PySide6.QtGui import QFont
import sys
import bcrypt
import random

class RegistrationUI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Employee Registration")
        self.showMaximized()
        self.main_ui = main_ui
        
        layout = QVBoxLayout()
        
        # Dynamic Header Controlled by Main_UI
        self.menu_layout = QHBoxLayout()
        layout.addLayout(self.menu_layout)
        self.update_menu()
        
        title = QLabel("Register New Employee")
        title.setFont(QFont("Arial", 16))
        layout.addWidget(title)
        
        self.entries = {}
        labels = ["Username", "First Name", "Last Name", "Email", "DOB", "Address", "Phone Number", "City", "State", "Zip Code", "Password"]
        
        for label in labels:
            lbl = QLabel(f"{label}:")
            entry = QLineEdit()
            if label == "Password":
                entry.setEchoMode(QLineEdit.Password)
            layout.addWidget(lbl)
            layout.addWidget(entry)
            self.entries[label] = entry
        
        # Role Selection
        role_label = QLabel("Role:")
        self.role_dropdown = QComboBox()
        self.role_dropdown.addItems(["Owner", "Manager", "Cashier", "Baker"])
        layout.addWidget(role_label)
        layout.addWidget(self.role_dropdown)
        
        # Register Button
        register_btn = QPushButton("Register")
        register_btn.clicked.connect(self.register)
        layout.addWidget(register_btn)
        
        # Home Button
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self.go_home)
        layout.addWidget(home_btn)
        
        # Back Button
        back_btn = QPushButton("Back to Login")
        back_btn.clicked.connect(self.go_back)
        layout.addWidget(back_btn)
        
        self.setLayout(layout)
    
    def update_menu(self):
        """Updates the menu dynamically based on role from Main_UI."""
        for i in reversed(range(self.menu_layout.count())):
            self.menu_layout.itemAt(i).widget().setParent(None)
        
        role_menus = {
            "Owner": ["POS", "Inventory", "Scheduling", "Payroll", "Register"],
            "Manager": ["POS", "Inventory", "Scheduling", "Payroll", "Register"],
            "Cashier": ["POS", "Timeclock", "My Earnings"],
            "Baker": ["Inventory", "Timeclock", "My Earnings"]
        }
        
        menu_items = role_menus.get(self.main_ui.current_role, [])
        for item in menu_items:
            btn = QPushButton(item)
            btn.clicked.connect(lambda _, page=item: self.main_ui.load_page(page))
            self.menu_layout.addWidget(btn)
    
    def register(self):
        """Registers a new employee, verifies role."""
        current_role = self.main_ui.current_role
        if current_role not in ["Owner", "Manager"]:
            print("Error: Only Owner or Manager can register new users!")
            return
        
        employee_id = "EMP" + str(random.randint(1000, 9999))
        
        data = {key: self.entries[key].text().strip() for key in self.entries}
        role = self.role_dropdown.currentText().strip()
        
        if not all(data.values()) or not role:
            print("Error: All fields must be filled!")
            return
        
        hashed_password = bcrypt.hashpw(data["Password"].encode(), bcrypt.gensalt()).decode()
        
        print(f"New Employee Registered: {data['Username']}, Role: {role}")
    
    def go_back(self):
        """Return to the login screen."""
        self.main_ui.login_ui()
    
    def go_home(self):
        """Navigate back to the appropriate home screen based on role."""
        self.main_ui.load_home(self.main_ui.current_role)

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = RegistrationUI(None)  # For testing purposes
    window.show()
    sys.exit(app.exec())
