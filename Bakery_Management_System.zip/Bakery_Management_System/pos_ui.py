from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget, QTableWidgetItem, QHBoxLayout
from PySide6.QtGui import QFont
import sys

class Pos_UI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Point of Sale (POS)")
        self.showMaximized()
        self.main_ui = main_ui
        
        layout = QVBoxLayout()
        
        title = QLabel("Point of Sale (POS)")
        title.setFont(QFont("Arial", 20))
        layout.addWidget(title)
        
        # Category Buttons
        categories = ["Cakes", "Cookies", "Pastries", "Breads"]
        category_layout = QHBoxLayout()
        for category in categories:
            btn = QPushButton(category)
            btn.clicked.connect(lambda _, cat=category: self.add_to_cart(cat))
            category_layout.addWidget(btn)
        layout.addLayout(category_layout)
        
        # Cart Table
        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(3)
        self.cart_table.setHorizontalHeaderLabels(["Item", "Price", "Quantity"])
        layout.addWidget(self.cart_table)
        
        # Checkout Button
        checkout_btn = QPushButton("Checkout")
        checkout_btn.clicked.connect(self.checkout)
        layout.addWidget(checkout_btn)
        
        # Home Button
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self.go_home)
        layout.addWidget(home_btn)
        
        self.setLayout(layout)
    
    def add_to_cart(self, item):
        """Add selected item to cart."""
        row_position = self.cart_table.rowCount()
        self.cart_table.insertRow(row_position)
        self.cart_table.setItem(row_position, 0, QTableWidgetItem(item))
        self.cart_table.setItem(row_position, 1, QTableWidgetItem("$5.00"))  # Placeholder price
        self.cart_table.setItem(row_position, 2, QTableWidgetItem("1"))  # Default quantity
    
    def checkout(self):
        """Handle the checkout process."""
        print("Proceeding to checkout...")
    
    def go_home(self):
        """Navigate back to the appropriate home screen based on role."""
        self.main_ui.load_home(self.main_ui.current_role)

# Run the application for testing
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Pos_UI(None)  # For testing purposes
    window.show()
    sys.exit(app.exec())