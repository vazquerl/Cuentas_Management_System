from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget,
    QTableWidgetItem, QHBoxLayout, QGridLayout, QMessageBox, QLineEdit
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
import sys

class Pos_UI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Bakery POS")
        self.resize(1200, 800)
        self.main_ui = main_ui
        self.tax_rate = 0.056

        main_layout = QHBoxLayout()

        # Left side: Categories and Items
        left_layout = QVBoxLayout()

        category_layout = QHBoxLayout()
        categories = ["Special Deals", "Bread", "Cakes", "Pastries", "Cookies"]
        for category in categories:
            btn = QPushButton(category)
            btn.setFixedHeight(40)
            btn.setStyleSheet("border-radius: 15px; padding: 8px;")
            btn.clicked.connect(lambda _, cat=category: self.select_category(cat))
            category_layout.addWidget(btn)
        left_layout.addLayout(category_layout)

        self.items_grid = QGridLayout()
        left_layout.addLayout(self.items_grid)

        main_layout.addLayout(left_layout, 2)

        # Right side: Order summary and actions
        right_layout = QVBoxLayout()

        title = QLabel("Current Order")
        title.setFont(QFont("Arial", 18))
        right_layout.addWidget(title)

        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(3)
        self.cart_table.setHorizontalHeaderLabels(["Item", "Price", "Quantity"])
        right_layout.addWidget(self.cart_table)

        self.calc_display = QLineEdit()
        self.calc_display.setFixedHeight(35)
        self.calc_display.setStyleSheet("border-radius: 15px; padding: 8px;")
        right_layout.addWidget(self.calc_display)

        calc_layout = QGridLayout()
        calc_buttons = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "0", ".", "Clear"]
        for idx, btn_text in enumerate(calc_buttons):
            btn = QPushButton(btn_text)
            btn.setFixedSize(60, 50)
            btn.setStyleSheet("border-radius: 15px;")
            calc_layout.addWidget(btn, idx // 3, idx % 3)
        right_layout.addLayout(calc_layout)

        payment_layout = QHBoxLayout()
        payments = ["Cash", "Card", "Cash App", "Google Pay", "Apple Pay"]
        for method in payments:
            pay_btn = QPushButton(method)
            pay_btn.setFixedHeight(40)
            pay_btn.setStyleSheet("border-radius: 15px; padding: 8px;")
            payment_layout.addWidget(pay_btn)
        right_layout.addLayout(payment_layout)

        order_type_layout = QHBoxLayout()
        for option in ["Dine-In", "Take-Out", "Delivery"]:
            btn = QPushButton(option)
            btn.setFixedHeight(40)
            btn.setStyleSheet("border-radius: 15px; padding: 8px;")
            order_type_layout.addWidget(btn)
        right_layout.addLayout(order_type_layout)

        checkout_btn = QPushButton("Checkout")
        checkout_btn.setFixedHeight(45)
        checkout_btn.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 20px;")
        checkout_btn.clicked.connect(self.checkout)
        right_layout.addWidget(checkout_btn)

        home_btn = QPushButton("Home")
        home_btn.setFixedHeight(45)
        home_btn.setStyleSheet("background-color: #2196F3; color: white; border-radius: 20px;")
        home_btn.clicked.connect(self.go_home)
        right_layout.addWidget(home_btn)

        main_layout.addLayout(right_layout, 3)
        self.setLayout(main_layout)
        self.select_category("Special Deals")

    def select_category(self, category):
        bakery_items = {
            "Special Deals": ["Family Pack - $15", "Dozen Cookies - $8", "Pastry Trio - $7"],
            "Bread": ["Sourdough - $5", "Baguette - $4", "Focaccia - $6"],
            "Cakes": ["Chocolate Cake - $15", "Cheesecake - $12", "Red Velvet - $14"],
            "Pastries": ["Croissant - $3", "Danish - $4", "Apple Turnover - $3"],
            "Cookies": ["Choc Chip - $2", "Oatmeal Raisin - $2", "Sugar Cookies - $2"]
        }

        for i in reversed(range(self.items_grid.count())):
            widget = self.items_grid.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        items = bakery_items.get(category, [])
        for idx, item in enumerate(items):
            btn = QPushButton(item)
            btn.setFixedSize(160, 80)
            btn.setStyleSheet("border-radius: 20px;")
            btn.clicked.connect(lambda _, itm=item: self.add_to_cart(itm))
            self.items_grid.addWidget(btn, idx // 3, idx % 3)

    def add_to_cart(self, item):
        name, price = item.rsplit(" - $", 1)
        row_position = self.cart_table.rowCount()
        self.cart_table.insertRow(row_position)
        self.cart_table.setItem(row_position, 0, QTableWidgetItem(name))
        self.cart_table.setItem(row_position, 1, QTableWidgetItem(price))
        self.cart_table.setItem(row_position, 2, QTableWidgetItem("1"))

    def checkout(self):
        subtotal = sum(float(self.cart_table.item(row, 1).text()) * int(self.cart_table.item(row, 2).text()) for row in range(self.cart_table.rowCount()))
        tax = subtotal * self.tax_rate
        total = subtotal + tax
        QMessageBox.information(self, "Checkout", f"Subtotal: ${subtotal:.2f}\nTax: ${tax:.2f}\nTotal: ${total:.2f}")

    def go_home(self):
        self.main_ui.load_home()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Pos_UI(None)
    window.show()
    sys.exit(app.exec())