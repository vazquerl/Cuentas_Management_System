from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget,
    QTableWidgetItem, QHBoxLayout, QLineEdit, QMessageBox, QComboBox, QFormLayout
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
import sys

class SchedulingUI(QWidget):
    def __init__(self, main_ui=None):
        super().__init__()
        self.setWindowTitle("Employee Scheduling")
        self.resize(1000, 700)
        self.main_ui = main_ui

        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)

        title = QLabel("Employee Scheduling")
        title.setFont(QFont("Arial", 20))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        self.schedule_table = QTableWidget()
        self.schedule_table.setColumnCount(4)
        self.schedule_table.setHorizontalHeaderLabels(["Employee", "Date", "Start Time", "End Time"])
        main_layout.addWidget(self.schedule_table)

        form_layout = QFormLayout()
        form_layout.setSpacing(10)

        employee_label = QLabel("Employee:")
        self.employee_dropdown = QComboBox()
        self.employee_dropdown.setFixedHeight(35)
        self.employee_dropdown.setStyleSheet("border-radius: 10px; padding-left: 8px;")
        self.employee_dropdown.addItems(["John Doe", "Jane Smith", "Alice Brown", "Michael Johnson"])
        form_layout.addRow(employee_label, self.employee_dropdown)

        self.entries = {}
        fields = ["Date (YYYY-MM-DD)", "Start Time (HH:MM)", "End Time (HH:MM)"]
        for field in fields:
            entry = QLineEdit()
            entry.setFixedHeight(35)
            entry.setStyleSheet("border-radius: 10px; padding-left: 8px;")
            form_layout.addRow(QLabel(field), entry)
            self.entries[field] = entry

        main_layout.addLayout(form_layout)

        button_layout = QHBoxLayout()

        add_button = QPushButton("Add Schedule")
        add_button.setFixedHeight(40)
        add_button.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 20px;")
        add_button.clicked.connect(self.add_schedule)
        button_layout.addWidget(add_button)

        delete_button = QPushButton("Delete Schedule")
        delete_button.setFixedHeight(40)
        delete_button.setStyleSheet("background-color: #f44336; color: white; border-radius: 20px;")
        delete_button.clicked.connect(self.delete_schedule)
        button_layout.addWidget(delete_button)

        home_btn = QPushButton("Home")
        home_btn.setFixedHeight(40)
        home_btn.setStyleSheet("background-color: #2196F3; color: white; border-radius: 20px;")
        home_btn.clicked.connect(self.go_home)
        button_layout.addWidget(home_btn)

        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)

    def add_schedule(self):
        employee = self.employee_dropdown.currentText()
        date = self.entries["Date (YYYY-MM-DD)"].text()
        start_time = self.entries["Start Time (HH:MM)"].text()
        end_time = self.entries["End Time (HH:MM)"].text()

        if not all([date, start_time, end_time]):
            QMessageBox.warning(self, "Error", "Please fill in all fields.")
            return

        row_position = self.schedule_table.rowCount()
        self.schedule_table.insertRow(row_position)
        self.schedule_table.setItem(row_position, 0, QTableWidgetItem(employee))
        self.schedule_table.setItem(row_position, 1, QTableWidgetItem(date))
        self.schedule_table.setItem(row_position, 2, QTableWidgetItem(start_time))
        self.schedule_table.setItem(row_position, 3, QTableWidgetItem(end_time))

        QMessageBox.information(self, "Success", "Schedule added successfully!")

    def delete_schedule(self):
        selected_row = self.schedule_table.currentRow()
        if selected_row != -1:
            self.schedule_table.removeRow(selected_row)
            QMessageBox.information(self, "Success", "Schedule deleted successfully!")

    def go_home(self):
        self.main_ui.load_home()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SchedulingUI()
    window.show()
    sys.exit(app.exec())