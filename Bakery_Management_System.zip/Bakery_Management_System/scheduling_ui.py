from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QTableWidget, QTableWidgetItem, QHBoxLayout, QLineEdit, QComboBox
from PySide6.QtGui import QFont
import sys

class SchedulingUI(QWidget):
    def __init__(self, main_ui):
        super().__init__()
        self.setWindowTitle("Employee Scheduling")
        self.showMaximized()
        self.main_ui = main_ui
        
        layout = QVBoxLayout()
        
        title = QLabel("Employee Scheduling")
        title.setFont(QFont("Arial", 16))
        layout.addWidget(title)
        
        # Schedule Table
        self.schedule_table = QTableWidget()
        self.schedule_table.setColumnCount(4)
        self.schedule_table.setHorizontalHeaderLabels(["Employee", "Date", "Start Time", "End Time"])
        layout.addWidget(self.schedule_table)
        
        # Input Fields
        self.entries = {}
        fields = ["Date (YYYY-MM-DD)", "Start Time (HH:MM)", "End Time (HH:MM)"]
        
        employee_label = QLabel("Employee:")
        self.employee_dropdown = QComboBox()
        self.employee_dropdown.addItems(["John Doe", "Jane Smith", "Alice Brown", "Michael Johnson"]) # Placeholder employees
        layout.addWidget(employee_label)
        layout.addWidget(self.employee_dropdown)
        
        for field in fields:
            label = QLabel(field)
            entry = QLineEdit()
            layout.addWidget(label)
            layout.addWidget(entry)
            self.entries[field] = entry
        
        # Action Buttons
        button_layout = QHBoxLayout()
        
        add_button = QPushButton("Add Schedule")
        add_button.clicked.connect(self.add_schedule)
        button_layout.addWidget(add_button)
        
        delete_button = QPushButton("Delete Schedule")
        delete_button.clicked.connect(self.delete_schedule)
        button_layout.addWidget(delete_button)
        
        layout.addLayout(button_layout)
        
        # Home Button
        home_btn = QPushButton("Home")
        home_btn.clicked.connect(self.go_home)
        layout.addWidget(home_btn)
        
        self.setLayout(layout)
    
    def add_schedule(self):
        """Adds a new schedule entry."""
        employee_name = self.employee_dropdown.currentText()
        schedule_date = self.entries["Date (YYYY-MM-DD)"].text()
        start_time = self.entries["Start Time (HH:MM)"].text()
        end_time = self.entries["End Time (HH:MM)"].text()
        
        if not all([employee_name, schedule_date, start_time, end_time]):
            print("Error: All fields must be filled!")
            return
        
        row_position = self.schedule_table.rowCount()
        self.schedule_table.insertRow(row_position)
        for col, data in enumerate([employee_name, schedule_date, start_time, end_time]):
            self.schedule_table.setItem(row_position, col, QTableWidgetItem(str(data)))
        
        print("Schedule added successfully!")
    
    def delete_schedule(self):
        """Deletes the selected schedule entry."""
        selected_row = self.schedule_table.currentRow()
        if selected_row == -1:
            print("Error: No schedule selected!")
            return
        
        self.schedule_table.removeRow(selected_row)
        print("Schedule deleted successfully!")
    
    def go_home(self):
        """Navigate back to the appropriate home screen based on role."""
        self.main_ui.load_home(self.main_ui.current_role)

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SchedulingUI(None)  # For testing purposes
    window.show()
    sys.exit(app.exec())