import sqlite3

DB_NAME = "bakery_system.db"

def connect_db():
    """Establish a connection to the SQLite database."""
    return sqlite3.connect(DB_NAME)