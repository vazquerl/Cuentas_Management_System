from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, QComboBox, QHBoxLayout, QMessageBox
from PySide6.QtGui import QFont
import sys
from registration_ui import RegistrationUI
from pos_ui import Pos_UI
from inventory_ui import InventoryUI
from scheduling_ui import SchedulingUI
from payroll_ui import PayrollUI

class MainUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cuentas Management Systems")
        self.showMaximized()
        
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)
        self.current_screen = None
        self.current_role = None
        
        self.login_ui()
    
    def clear_layout(self):
        """Remove all widgets from the layout before switching screens, except system buttons."""
        for i in reversed(range(self.layout.count())):
            widget = self.layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)
    
    def show_screen(self, screen):
        """Switch dynamically between different UI sections and remove previous instances."""
        self.clear_layout()
        self.current_screen = screen
        self.layout.addWidget(self.current_screen)
    
    def login_ui(self):
        """Login UI in the main window."""
        self.clear_layout()
        self.current_screen = None
        
        title = QLabel("Welcome to Cuentas Management Systems")
        title.setFont(QFont("Arial", 24))
        self.layout.addWidget(title)
        
        subtitle = QLabel("Log in or register to continue.")
        subtitle.setFont(QFont("Arial", 16))
        self.layout.addWidget(subtitle)
        
        self.username_entry = QLineEdit()
        self.username_entry.setPlaceholderText("Username")
        self.layout.addWidget(self.username_entry)
        
        self.password_entry = QLineEdit()
        self.password_entry.setPlaceholderText("Password")
        self.password_entry.setEchoMode(QLineEdit.Password)
        self.layout.addWidget(self.password_entry)
        
        login_btn = QPushButton("Login")
        login_btn.clicked.connect(self.attempt_login)
        self.layout.addWidget(login_btn)
        
        register_btn = QPushButton("Register")
        register_btn.clicked.connect(self.register_verification_ui)
        self.layout.addWidget(register_btn)
    
    def attempt_login(self):
        """Verify username and password and assign correct role."""
        username = self.username_entry.text().lower()
        password = self.password_entry.text()
        
        valid_users = {
            "admin": "admin123",
            "manager": "manager123"
        }
        
        if username in valid_users and valid_users[username] == password:
            self.current_role = "Owner" if username == "admin" else "Manager"
            self.load_home()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid username or password.")
    
    def register_verification_ui(self):
        """Only allow Managers or Owners to access registration."""
        if self.current_role not in ["Owner", "Manager"]:
            QMessageBox.warning(self, "Access Denied", "Only Owners and Managers can register new users.")
            return
        self.show_screen(RegistrationUI(self))
    
    def load_home(self):
        """Load the correct home screen based on role."""
        self.clear_layout()
        
        role_label = QLabel(f"Welcome, {self.current_role}")
        role_label.setFont(QFont("Arial", 20))
        self.layout.addWidget(role_label)
        
        self.menu_layout = self.get_header_layout()
        self.layout.addLayout(self.menu_layout)
    
    def get_header_layout(self):
        """Return the appropriate header layout based on user role."""
        header_layout = QHBoxLayout()
        
        role_menus = {
            "Owner": ["POS", "Inventory", "Scheduling", "Payroll", "Register"],
            "Manager": ["POS", "Inventory", "Scheduling", "Payroll", "Register"],
            "Cashier": ["POS", "Timeclock", "My Earnings"],
            "Baker": ["Inventory", "Timeclock", "My Earnings"]
        }
        
        menu_items = role_menus.get(self.current_role, [])
        for item in menu_items:
            btn = QPushButton(item)
            btn.clicked.connect(lambda _, page=item: self.load_page(page))
            header_layout.addWidget(btn)
        
        return header_layout
    
    def load_page(self, page):
        """Load the selected page dynamically."""
        page_mapping = {
            "POS": Pos_UI,
            "Inventory": InventoryUI,
            "Scheduling": SchedulingUI,
            "Payroll": PayrollUI,
            "Register": RegistrationUI
        }
        
        if page in page_mapping:
            self.show_screen(page_mapping[page](self))
    
    def logout(self):
        """Log the user out, clear the screen, and return to login UI."""
        self.current_role = None
        self.login_ui()

# Run the application
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainUI()
    window.show()
    sys.exit(app.exec())