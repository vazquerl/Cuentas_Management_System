from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QLineEdit, 
    QHBoxLayout, QMessageBox, QFormLayout, QSpacerItem, QSizePolicy
)
from PySide6.QtGui import QFont, QPalette, QColor
from PySide6.QtCore import Qt
import sys
from registration_ui import RegistrationUI
from pos_ui import Pos_UI
from inventory_ui import InventoryUI
from scheduling_ui import SchedulingUI
from payroll_ui import PayrollUI

class MainUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cuentas Management Systems")
        self.resize(800, 600)
        self.is_dark_mode = False
        self.current_role = None

        self.layout = QVBoxLayout()
        self.layout.setAlignment(Qt.AlignCenter)
        self.setLayout(self.layout)

        self.login_ui()
        self.apply_light_theme()

    def clear_layout(self, layout=None):
        if layout is None:
            layout = self.layout

        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
            elif child.layout():
                self.clear_layout(child.layout())

    def show_screen(self, screen):
        self.clear_layout()
        self.layout.addWidget(screen)

    def login_ui(self):
        self.clear_layout()
        self.layout.setAlignment(Qt.AlignCenter)

        title = QLabel("Welcome to Cuentas Management Systems")
        title.setFont(QFont("Arial", 24))
        title.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(title)

        subtitle = QLabel("Log in or register to continue.")
        subtitle.setFont(QFont("Arial", 16))
        subtitle.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(subtitle)

        form_layout = QVBoxLayout()
        form_layout.setAlignment(Qt.AlignCenter)

        self.username_entry = QLineEdit()
        self.username_entry.setPlaceholderText("Username")
        self.username_entry.setFixedHeight(35)
        self.username_entry.setMaximumWidth(self.width() // 2)
        self.username_entry.setStyleSheet(
            "border-radius: 10px; padding-left: 10px; border: 1px solid #ccc;")
        form_layout.addWidget(self.username_entry)

        self.password_entry = QLineEdit()
        self.password_entry.setPlaceholderText("Password")
        self.password_entry.setEchoMode(QLineEdit.Password)
        self.password_entry.setFixedHeight(35)
        self.password_entry.setMaximumWidth(self.width() // 2)
        self.password_entry.setStyleSheet(
            "border-radius: 10px; padding-left: 10px; border: 1px solid #ccc;")
        form_layout.addWidget(self.password_entry)

        self.layout.addLayout(form_layout)

        buttons_layout = QHBoxLayout()
        buttons_layout.setAlignment(Qt.AlignCenter)
        buttons_layout.setSpacing(20)

        login_btn = QPushButton("Login")
        login_btn.setFixedSize(120, 40)
        login_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50; color: white; border-radius: 10px;
                padding: 8px; font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #397d3b;
            }
        """)
        login_btn.clicked.connect(self.attempt_login)
        buttons_layout.addWidget(login_btn)

        register_btn = QPushButton("Register")
        register_btn.setFixedSize(120, 40)
        register_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3; color: white; border-radius: 10px;
                padding: 8px; font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1e88e5;
            }
            QPushButton:pressed {
                background-color: #1565c0;
            }
        """)
        register_btn.clicked.connect(self.register_verification_ui)
        buttons_layout.addWidget(register_btn)

        self.layout.addLayout(buttons_layout)

        self.theme_btn = QPushButton("🌞" if not self.is_dark_mode else "🌜")
        self.theme_btn.setFixedSize(40, 40)
        self.theme_btn.setStyleSheet("border: none; font-size: 20px;")
        self.theme_btn.clicked.connect(self.toggle_theme)
        self.layout.addWidget(self.theme_btn, alignment=Qt.AlignCenter)

    # (All other methods remain unchanged)


    def attempt_login(self):
        username = self.username_entry.text().lower()
        password = self.password_entry.text()

        valid_users = {"admin": "admin123", "manager": "manager123"}

        if username in valid_users and valid_users[username] == password:
            self.current_role = "Owner" if username == "admin" else "Manager"
            self.load_home()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid username or password.")

    def register_verification_ui(self):
        if self.current_role not in ["Owner", "Manager"]:
            QMessageBox.warning(self, "Access Denied", "Only Owners and Managers can register new users.")
            return
        self.show_screen(RegistrationUI(self))

    def load_home(self):
        self.clear_layout()

        role_label = QLabel(f"Welcome, {self.current_role}")
        role_label.setFont(QFont("Arial", 20))
        role_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(role_label)

        menu_layout = self.get_header_layout()
        self.layout.addLayout(menu_layout)

        self.theme_btn = QPushButton("🌞")
        self.theme_btn.setFixedSize(40, 40)
        self.theme_btn.clicked.connect(self.toggle_theme)
        self.layout.addWidget(self.theme_btn, alignment=Qt.AlignCenter)

        logout_btn = QPushButton("Logout")
        logout_btn.setFixedHeight(40)
        logout_btn.setStyleSheet("background-color: #f44336; color: white; border-radius: 20px;")
        logout_btn.clicked.connect(self.logout)
        self.layout.addWidget(logout_btn)

    def get_header_layout(self):
        header_layout = QHBoxLayout()
        role_menus = {
            "Owner": ["POS", "Inventory", "Scheduling", "Payroll", "Register"],
            "Manager": ["POS", "Inventory", "Scheduling", "Payroll", "Register"],
            "Cashier": ["POS", "Timeclock", "My Earnings"],
            "Baker": ["Inventory", "Timeclock", "My Earnings"]
        }

        menu_items = role_menus.get(self.current_role, [])
        for item in menu_items:
            btn = QPushButton(item)
            btn.setFixedHeight(35)
            btn.setStyleSheet("border-radius: 15px; padding: 8px;")
            btn.clicked.connect(lambda _, page=item: self.load_page(page))
            header_layout.addWidget(btn)
        return header_layout

    def load_page(self, page):
        page_mapping = {"POS": Pos_UI, "Inventory": InventoryUI, "Scheduling": SchedulingUI, "Payroll": PayrollUI, "Register": RegistrationUI}

        if page in page_mapping:
            self.show_screen(page_mapping[page](self))

    def logout(self):
        self.current_role = None
        self.login_ui()

    def toggle_theme(self):
        if self.is_dark_mode:
            self.apply_light_theme()
            self.theme_btn.setText("🌞")
        else:
            self.apply_dark_theme()
            self.theme_btn.setText("🌜")
        self.is_dark_mode = not self.is_dark_mode

    def apply_dark_theme(self):
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor("#2b2b2b"))
        palette.setColor(QPalette.WindowText, QColor("#ffffff"))
        self.setPalette(palette)

    def apply_light_theme(self):
        palette = QPalette()
        self.setPalette(palette)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainUI()
    window.show()
    sys.exit(app.exec())
